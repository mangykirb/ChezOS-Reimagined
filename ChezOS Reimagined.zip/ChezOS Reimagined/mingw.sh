#!/usr/bin/env bash
g++ src/main.cpp \
external/imgui/imgui.cpp \
external/imgui/imgui_draw.cpp \
external/imgui/imgui_tables.cpp \
external/imgui/imgui_widgets.cpp \
external/imgui/backends/imgui_impl_glfw.cpp \
external/imgui/backends/imgui_impl_opengl3.cpp \
-Iexternal/imgui \
-Iexternal/imgui/backends \
-Iexternal/glfw/include \
-Lexternal/glfw/build/src \
-lglfw3 -lopengl32 -lgdi32 \
-o ChezOSR.exe -Os -s

