hi
so well, i come to you with ChezOS Reimagined!
it uses ImGui, so it looks like 2.41x better,
and actually drippy!

### **how to use?**
firstly, you have to open ChezOSR.exe
Expect:
1. nothing for 0.5-1s 
2. screen goes dark for 1-3s
and theres chezos.
To turn off, either shutdown (button in ChezOSR) or ALT + F4 (alt + tab)
all of these methods cause number 2 cuz idk
theres not a lot for now, but atleast its open source!