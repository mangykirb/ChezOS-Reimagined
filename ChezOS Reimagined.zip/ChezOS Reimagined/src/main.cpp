#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"
#include <GLFW/glfw3.h>
#include <iostream>
#include "std/stdlib.hpp"
#include <Windows.h>
#include <filesystem>
int main()
{
    nlohmann::json config;
    StdLib::fileCreateInfo info;
   
    info.content = config.dump();
    StdLib::createFile(info, std::ofstream("disk/config.json"));

    if (!glfwInit())
        return -1;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());
    GLFWwindow* window = glfwCreateWindow(mode->width, mode->height, "ImGui GLFW OpenGL", glfwGetPrimaryMonitor(), NULL);
    if (!window)
        return -1;
    glfwSetWindowTitle(window, "ChezOS");
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        ImGuiIO& io = ImGui::GetIO();
        float taskbarHeight = 40.0f;

        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x, io.DisplaySize.y - taskbarHeight));

        if(!std::filesystem::exists("disk")){
            std::cerr << "Expected disk folder, not found.\n";
            MessageBoxA(NULL, "Expected disk folder, not found.\n", "Error", MB_ICONERROR | MB_OK); // if the user wasnt running it from terminal
            return -1;
        }

        ImGui::Text("nothing... yet");
        bool firstBoot = config["firstBoot?"];

        if (firstBoot)
        {

            ImVec2 center = ImGui::GetMainViewport()->GetCenter();
            ImGui::SetNextWindowPos(center, ImGuiCond_Always, ImVec2(0.5f, 0.5f));
            ImGui::SetNextWindowSize(ImVec2(500, 250));

            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 20.69f);
            ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.08f, 0.08f, 0.12f, 1.0f));

            ImGui::Begin("Welcome to ChezOS", nullptr);

            ImGui::Spacing();
            ImGui::SetWindowFontScale(1.5f);
            ImGui::Text("Welcome to ChezOS!");
            ImGui::SetWindowFontScale(1.0f);

            ImGui::Separator();
            ImGui::Spacing();

            ImGui::TextWrapped(
                "It looks like this is your first time booting ChezOS.\n\n"
                "This is a tiny operating-system-style UI made with ImGui "
                "and OpenGL."
            );

            ImGui::Spacing();
            ImGui::Spacing();

            if (ImGui::Button("Continue", ImVec2(120, 40)))
            {
                config["firstBoot?"] = false;
                std::ofstream out("disk/config.json");
                out << config.dump(4);
                out.close();
            }

            ImGui::SameLine();

            if (ImGui::Button("Shutdown", ImVec2(120, 40)))
            {
                glfwSetWindowShouldClose(window, true);
            }

            ImGui::PopStyleVar();
            ImGui::PopStyleColor();
        }
        else
        {
            ImGui::SetNextWindowPos(ImVec2(0, 0));
            ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x, io.DisplaySize.y - taskbarHeight));

            ImGui::Begin("Desktop", nullptr,
                ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoCollapse);

            ImGui::Text("ChezOS Desktop");


        }
            
        ImGui::End();

        ImGui::SetNextWindowPos(ImVec2(0, io.DisplaySize.y - taskbarHeight));
        ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x, taskbarHeight));

        ImGui::Begin("Taskbar", nullptr,
            ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoSavedSettings);

        if (ImGui::Button("Shutdown", ImVec2(200, 30)))
            glfwSetWindowShouldClose(window, true);

        ImGui::SameLine();
        ImGui::SetCursorPosX( ImGui::GetWindowWidth() - ImGui::CalcTextSize("12:00").x - 10);
        ImGui::Text("12:00");

        ImGui::End();

        ImGui::Render();

        int w, h;
        glfwGetFramebufferSize(window, &w, &h);

        glViewport(0, 0, w, h);
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}