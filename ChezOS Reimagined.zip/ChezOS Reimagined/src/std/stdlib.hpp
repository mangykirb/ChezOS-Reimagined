#pragma once

#include <iostream>
#include <windows.h>
#include <fstream>
#include "json.hpp"
#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"
#include <GLFW/glfw3.h>

class StdLib
{
public:
    struct fileCreateInfo
    {
        std::string content;
    };

    static void createFile(fileCreateInfo info, std::ofstream file)
    {
        if (file.is_open())
        {
            file << info.content;
            file.close();
        }
        else
        {
            std::cerr << "Unable to create file\n";
        }
    }
};